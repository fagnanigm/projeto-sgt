
<?php 


echo hash('sha256', "teste123"); 

?>