<?php

define('SERVER_NAME_SQL','DESKTOP-JS575OC');
define('SERVER_CON_DATABASE','NecBrasil_Emissor_CTE');



?>