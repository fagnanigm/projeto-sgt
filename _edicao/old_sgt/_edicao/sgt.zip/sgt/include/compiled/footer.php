	<footer class="margin-top-20">
		<div class="container text-center">
			<p>&copy; <?php echo date("Y"); ?> N&C Brasil &middot;  <a href="#">Privacidade</a> &middot; <a href="#">Termos</a></p>
		</div>
	</footer>

	<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
	<script src="/assets/js/custom.js"></script>

	<!-- angular scripts -->
    <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.5.3/angular.min.js"></script>
    <script src="/assets/js/ngMask-master/dist/ngMask.min.js"></script>
	<script src="/controller/app.js"></script>

	<script src="/controller/cte/controller.cte.js"></script>

</body>
</html>	
