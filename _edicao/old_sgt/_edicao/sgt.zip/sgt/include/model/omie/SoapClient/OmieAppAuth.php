<?php
// Omie API Key
//  Company: Empresa Modelo - BRAZIL CHANELL
//  Date:    Jun 10 2017 03:11:42:000PM

define("OMIE_APP_KEY",    "7722651396");
define("OMIE_APP_SECRET", "dc643a3cf2fcde9c3b7c6e561bfb3b9f");
?>